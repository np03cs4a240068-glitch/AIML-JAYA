<?php
// Initialize variables
$errors = [];
$success = '';
$name = $email = '';

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    // Validate name
    if (empty($name)) {
        $errors['name'] = 'Name is required';
    }
    
    // Validate email
    if (empty($email)) {
        $errors['email'] = 'Email is required';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Invalid email format';
    }
    
    // Validate password
    if (empty($password)) {
        $errors['password'] = 'Password is required';
    } elseif (strlen($password) < 8) {
        $errors['password'] = 'Password must be at least 8 characters';
    } elseif (!preg_match('/[!@#$%^&*(),.?":{}|<>]/', $password)) {
        $errors['password'] = 'Password must contain at least one special character';
    }
    
    // Validate confirm password
    if (empty($confirm_password)) {
        $errors['confirm_password'] = 'Please confirm your password';
    } elseif ($password !== $confirm_password) {
        $errors['confirm_password'] = 'Passwords do not match';
    }
    
    // If no errors, process registration
    if (empty($errors)) {
        $jsonFile = 'users.json';
        
        // Read existing users
        if (file_exists($jsonFile)) {
            $jsonData = file_get_contents($jsonFile);
            $users = json_decode($jsonData, true);
            
            if ($users === null) {
                $errors['general'] = 'Error reading user data';
            }
        } else {
            $users = [];
        }
        
        if (empty($errors)) {
            // Hash password
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            
            // Create user array
            $newUser = [
                'name' => $name,
                'email' => $email,
                'password' => $hashedPassword
            ];
            
            // Add to users array
            $users[] = $newUser;
            
            // Write back to file
            $jsonEncoded = json_encode($users, JSON_PRETTY_PRINT);
            
            if (file_put_contents($jsonFile, $jsonEncoded) === false) {
                $errors['general'] = 'Error saving user data. Please check file permissions.';
            } else {
                $success = 'Registration successful! Your account has been created.';
                $name = $email = '';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>
</head>
<body>
    <h1>User Registration</h1>
    
    <?php if ($success): ?>
        <div class="success"><?php echo htmlspecialchars($success); ?></div>
    <?php endif; ?>
    
    <?php if (isset($errors['general'])): ?>
        <div class="error"><?php echo htmlspecialchars($errors['general']); ?></div>
    <?php endif; ?>
    
    <form method="POST" action="">
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>">
            <?php if (isset($errors['name'])): ?>
                <div class="error"><?php echo htmlspecialchars($errors['name']); ?></div>
            <?php endif; ?>
        </div>
        
        <div class="form-group">
            <label for="email">Email Address:</label>
            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>">
            <?php if (isset($errors['email'])): ?>
                <div class="error"><?php echo htmlspecialchars($errors['email']); ?></div>
            <?php endif; ?>
        </div>
        
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" id="password" name="password">
            <?php if (isset($errors['password'])): ?>
                <div class="error"><?php echo htmlspecialchars($errors['password']); ?></div>
            <?php endif; ?>
        </div>
        
        <div class="form-group">
            <label for="confirm_password">Confirm Password:</label>
            <input type="password" id="confirm_password" name="confirm_password">
            <?php if (isset($errors['confirm_password'])): ?>
                <div class="error"><?php echo htmlspecialchars($errors['confirm_password']); ?></div>
            <?php endif; ?>
        </div>
        
        <button type="submit">Register</button>
    </form>
</body>
</html>